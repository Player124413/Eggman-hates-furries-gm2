The source code takes the form of a Game Maker 7 gmk file.

To run it, you will need:
 - A copy of all of the (non-executable) files from the regular release version in the same directory as the gmk.
 - The full version of Game Maker 7.

There is currently no legal method of obtaining the full version of Game Maker 7. The gmk can be opened with the trial version, but the feature restrictions will prevent the game from running. Opening the gmk with Game Maker 8 or Studio is also possible, but this will introduce incompatibilities which will prevent the game from running.

Disclaimer:
The gmk is distributed with absolutely no warranty or support: Do not ask me for help or assistance with it.
The source code is unfit for reuse, and is not intended to be useful to you in any way.
Most of the included assets are not original works: License to reuse them is not provided and they cannot be attributed to the Oddwarg.
In no event shall the Oddwarg be liable for damages arising in connection with the use or performance of this content.